module.exports = {
  performance: {
    hints: false
  }
};
