---
title: Foundation
layout: vtabs
section: examples
weight: 100
template: yeti
---
### Zurb Foundation Template
You can combine these forms with the amazing [Bootswatch](https://bootswatch.com) templating system to create amazing looking forms. Check out this one which uses the Yeti design.

```html
<link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/yeti/bootstrap.min.css" rel="stylesheet">
<script src="https://unpkg.com/formiojs@latest/dist/formio.embed.js?src=https://examples.form.io/example"></script>
```

<script src="dist/formio.embed.js?src=https://examples.form.io/example"></script>
