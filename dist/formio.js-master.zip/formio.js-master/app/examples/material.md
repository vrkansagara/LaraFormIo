---
title: Material Design
layout: vtabs
section: examples
weight: 100
template: paper
---
### Material Design
You can combine these forms with the amazing [Bootswatch](https://bootswatch.com) templating system to create amazing looking forms. Check out this one which uses the Paper design.

```html
<link href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/paper/bootstrap.min.css" rel="stylesheet">
<script src="https://unpkg.com/formiojs@latest/dist/formio.embed.js?src=https://examples.form.io/example"></script>
```

<script src="dist/formio.embed.js?src=https://examples.form.io/example"></script>
